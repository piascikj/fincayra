config = {
	name:"Fincayra2"
}

//To load a file outside the scope of the application, do this
//load("/home/jpiasci/fincayra-config.js");
